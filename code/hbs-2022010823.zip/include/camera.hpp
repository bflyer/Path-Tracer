#ifndef CAMERA_H
#define CAMERA_H

#include "ray.hpp"
#include <vecmath.h>
#include <float.h>
#include <cmath>


class Camera {
public:
    Camera(const Vector3f &center, const Vector3f &direction, const Vector3f &up, int imgW, int imgH) {
        this->center = center;                                                      // 光心
        this->direction = direction.normalized();                                   // 相机视线方向
        this->horizontal = Vector3f::cross(this->direction, up).normalized();                    // 水平轴
        this->up = Vector3f::cross(this->horizontal, this->direction).normalized();              // up 方向
        this->width = imgW;                                                         // 成像屏幕宽度
        this->height = imgH;                                                        // 成像屏幕高度
    }

    // Generate rays for each screen-space coordinate
    virtual Ray generateRay(const Vector2f &point) = 0;
    virtual ~Camera() = default;

    int getWidth() const { return width; }
    int getHeight() const { return height; }

protected:
    // Extrinsic parameters
    Vector3f center;
    Vector3f direction;
    Vector3f up;
    Vector3f horizontal;
    // Intrinsic parameters
    int width;
    int height;
};

// You can add new functions or variables whenever needed.
class PerspectiveCamera : public Camera {

public:
    PerspectiveCamera(const Vector3f &center, const Vector3f &direction,
            const Vector3f &up, int imgW, int imgH, float angle)
            : Camera(center, direction, up, imgW, imgH) {
        // angle is in radian.
        cx = imgW / 2;                                     // 光心坐标
        cy = imgH / 2;
        fx = cy / tan(angle / 2);                          // 焦距
        fy = cy / tan(angle / 2);
    }

    Ray generateRay(const Vector2f &point) override {
        Vector3f d_rc = Vector3f((point[0] - cx) / fx, (cy - point[1]) / fy, 1);
        c2w = Matrix3f(horizontal, -up, direction, 1);  // 相机坐标系到世界坐标系的变换矩阵
        return Ray(center, c2w * d_rc);
    }

private:
    float fx;
    float fy;
    float cx;
    float cy;
    Matrix3f c2w;
};
#endif //CAMERA_H