#ifndef PLANE_H
#define PLANE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// function: ax+by+cz=d
// choose your representation , add more fields and fill in the functions

class Plane : public Object3D {
public:
    Plane() : normal(Vector3f::UP), d(0) {}

    Plane(const Vector3f &normal, float d, Material *m) : Object3D(m), d(d), normal(normal) {}

    ~Plane() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        // 1. 计算 t
        float t = (d - Vector3f::dot(normal, r.getOrigin())) / Vector3f::dot(normal, r.getDirection());
        // 2. 设置交点
        if (t < tmin || t >= h.getT()) {
            return false;
        } else {
            h.set(t, material, normal);
            return true;
        }
    }

protected:
    Vector3f normal;  // 平面法向量
    float d;          // 隐式表示中的 d
};

#endif //PLANE_H
		

