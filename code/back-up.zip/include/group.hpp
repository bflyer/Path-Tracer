#ifndef GROUP_H
#define GROUP_H


#include "object3d.hpp"
#include "ray.hpp"
#include "hit.hpp"
#include <iostream>
#include <vector>

class Group : public Object3D {

public:

    Group() {}

    explicit Group (int num_objects) : objList(num_objects) {}

    ~Group() override {}

    // 求最近交点
    bool intersect(const Ray &r, Hit &h, float tmin) override {
        bool flag = false;
        for (auto obj : objList)
            if (obj) flag |= obj->intersect(r, h, tmin);
        return flag;
    }

    void addObject(int index, Object3D *obj) {
        // TODO: 为什么需要有索引呢？直接插在最后不行吗？
        objList.push_back(obj);
        // objList.insert(objList.begin() + index, obj);
    }
    
    int getGroupSize() {
        return objList.size();
    }

private:
    std::vector<Object3D*> objList;
};

#endif
	
