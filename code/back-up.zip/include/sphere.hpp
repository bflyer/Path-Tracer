#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

class Sphere : public Object3D {
public:
    Sphere() : radius(0), center(0, 0, 0){}

    Sphere(const Vector3f &center, float radius, Material *material)
        : Object3D(material), center(center), radius(radius) {}

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        // 1. 计算由光源指向球心的向量 l
        Vector3f o(r.getOrigin()), dir(r.getDirection().normalized());
        Vector3f l(center - o);

        // 2. 判断光源是否位于球体内部
        bool position;  // false 表示内部， true 表示外部
        if (l.length() <= this->radius) {  // 内部或表面
            position = false;
        } else {  // 外部
            position = true;
        }

        // 3. 计算【球心】到【光线所在直线】的投影点（垂足）到光线起点的距离 foot
        float foot = Vector3f::dot(l, dir);
        // 若光源在球体外部并且和视线方向异侧，则必然不相交
        if (foot < 0 && position) {
            return false;
        }

        // 4. 计算球心到光线所在直线的距离的平方 d2
        float d2 = l.squaredLength() - foot * foot;
        // 若光源在球体外部且和视线方向同侧，但球心距离视线超过半径，则不相交
        if (d2 > radius * radius && position) {
            return false;
        }

        // 5. 计算【投影点】到【光线与球面的交点】的距离 delta
        float delta = sqrt(radius * radius - d2);

        // 6. 求解光线与球面的交点
        float t = position ? foot - delta : foot + delta;
        if (t < tmin || t >= h.getT()) {
            return false;
        } else {
            // 获取交点坐标及法向量
            Vector3f point(o + dir * t);
            Vector3f normal((point - center).normalized());
            h.set(t, material, normal);
            return true;
        }
    }

protected:
    Vector3f center;  // 球心
    float radius;     // 半径
};
#endif