#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "object3d.hpp"
#include "plane.hpp"
#include <vecmath.h>
#include <cmath>
#include <iostream>
using namespace std;

class Triangle: public Object3D {

public:
	Triangle() = delete;

    // a b c are three vertex positions of the triangle
	Triangle( const Vector3f& a, const Vector3f& b, const Vector3f& c, Material* m)
	: Object3D(m), v0(a), v1(b), v2(c) {
		normal = Vector3f::cross((b - a), (c - a)).normalized();
	}

	// 法一：中心坐标法直接求交
	bool intersect( const Ray& ray,  Hit& hit , float tmin) override {
		Vector3f dir = ray.getDirection();
		Vector3f e1 = v0 - v1;
		Vector3f e2 = v0 - v2;
		Vector3f s = v0 - ray.getOrigin();
		Matrix3f m1(s, e1, e2);
		Matrix3f m2(dir, s, e2);
		Matrix3f m3(dir, e1, s);
		Matrix3f m4(dir, e1, e2);
		float d1 = m1.determinant();
		float d2 = m2.determinant();
		float d3 = m3.determinant();
		float d4 = m4.determinant();
		float t = d1/d4;
		float b = d2/d4;
		float c = d3/d4;
		if (t <= hit.getT() && t >= tmin && b >= 0 && c >= 0 && b + c <= 1) {
			hit.set(t, material, normal);
			return true;
		} else {
			return false;
		}
	}

	// // 法二：先直接判断光线与三角形平面是否有交，然后判断交点是否在内部
	// bool intersect( const Ray& ray,  Hit& hit , float tmin) override {
	// 	float cos = Vector3f::dot(normal, ray.getDirection());
	// 	// 1. 判断光线与三角形平面是否有交
	// 	if (fabs(cos) < 1e-6) return false;
	// 	// 2. 找到交点
	// 	float d = Vector3f::dot(normal, v0);
	// 	float t = (d - Vector3f::dot(normal, ray.getOrigin())) / cos;
	// 	if (t > hit.getT() || t < tmin) return false;
	// 	Vector3f point(ray.getOrigin() + ray.getDirection() * t);
	// 	// 3. 判断交点是否在三角形内部
	// 	if (!inTriangle(point)) return false;
	// 	else {
	// 		hit.set(t, material, normal);
	// 		return true;
	// 	}
	// }


	Vector3f normal;
	Vector3f v0, v1, v2;
protected:
	bool inTriangle(const Vector3f& point) {
		return Vector3f::dot(Vector3f::cross(v1 - point, v2 - point), normal) >= -1e-6 &&
			   Vector3f::dot(Vector3f::cross(v2 - point, v0 - point), normal) >= -1e-6 &&
			   Vector3f::dot(Vector3f::cross(v0 - point, v1 - point), normal) >= -1e-6;
	}
};



#endif //TRIANGLE_H